from matplotlib import pyplot as plt

for cnt in range(0, 101, 10):
    data = [float(k.rstrip()) for k in open(f"{cnt}_data.txt").readlines()]
    plt.plot(data, label=str(cnt))
plt.legend()
plt.show()