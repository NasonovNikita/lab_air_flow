import jetFunctions as jf
import time

DSTEP = 5
START = 350
FINISH = 350

jf.initSpiAdc()
jf.initStepMotorGpio()
jf.stepBackward(START)
dist = input("Введите расстояние: ")

try:
    with open(f'{dist}_data.txt', 'w+') as f:
        for dx in range(0, START + FINISH + 1, DSTEP):
        
            data = []
            for i in range(100):
                data.append(jf.getAdc())
            f.write(str(sum(data) / 100) + "\n")

            jf.stepForward(DSTEP)
    jf.stepBackward(FINISH)
finally:
    jf.deinitSpiAdc()
    jf.deinitStepMotorGpio()