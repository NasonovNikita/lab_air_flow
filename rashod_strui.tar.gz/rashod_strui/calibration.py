import jetFunctions as jf
try:
    jf.initSpiAdc()
    with open('calibration_125Pa.txt', "w") as f:
        for i in range(1000):
            f.write(str(jf.getAdc()) + "\n")
finally:
    jf.deinitSpiAdc()